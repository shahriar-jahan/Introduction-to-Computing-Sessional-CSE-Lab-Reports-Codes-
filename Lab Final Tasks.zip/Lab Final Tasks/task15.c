//character and integer input
/*Sample Input and Output:
Enter n: 5
A
A
A
A
A*/
#include<stdio.h>
int main()
{
    int i,n;
    i=1;
    char c='A';
    printf("Enter n: ");
        scanf("%d",&n);
    do
    {  
        printf("%c\n",c);
        i++;
    } while (i<=n);
    
}