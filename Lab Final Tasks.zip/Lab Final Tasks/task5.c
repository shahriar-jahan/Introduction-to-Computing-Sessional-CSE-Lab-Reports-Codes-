//Take an integer input N as input and calculate
/*Sample Input: 10
Sample Output:
1+2+3+4+5+6+7+8+9+10+
Sum=55
*/
#include<stdio.h>
int main()
{
    int i,sum,n;
    sum=0;
    printf("enter N:");
    scanf("%d",&n);
    for ( i = 1; i <=n; i++)
    {
       printf("%d+",i);
       sum=sum+i;
    }
    printf("\nSum=%d",sum);
}