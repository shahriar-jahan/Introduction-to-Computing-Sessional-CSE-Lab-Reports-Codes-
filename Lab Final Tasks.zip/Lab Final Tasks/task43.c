#include <stdio.h>

int main() {
    while (1) {
        printf("Looping...\n");
        break;
    }
}