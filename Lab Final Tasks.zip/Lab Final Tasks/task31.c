//Calculate Factorial
/*Sample Input and Output:
N= 5
Factorial is: 120*/
#include<stdio.h>
int main()
{
    int n;
    int factorial=1;
    int i;
    printf("N= ");
    scanf("%d",&n);
    if (n<0)
    {
        printf("Error");
    }
    else{
        for ( i = 1; i<=n; i++)
        {
            factorial=factorial*i;
        }
        printf("Factorial is: %d\n",factorial);
    }
}