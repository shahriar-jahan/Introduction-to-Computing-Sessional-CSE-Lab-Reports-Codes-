#include <stdio.h>

int main() {
    for (;;) {
        printf("Infinite Loop\n");
    }
}