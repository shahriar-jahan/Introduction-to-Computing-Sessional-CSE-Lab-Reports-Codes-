//take a number and reverse it
/*Sample Input and Output:
Enter an integer: 12345 
Reversed Number: 54321*/
#include<stdio.h>
int main()
{
int num,rem,rev_num;
rev_num=0;
printf("Enter an integer: ");
scanf("%d",&num);
while (num!=0)
{
    rem=num%10;//get last digit
    rev_num=(rev_num*10)+rem;//shifting existing digit left and add new digits
    num=num/10;//remove last digit
}
printf("Reversed Number: %d",rev_num);
}