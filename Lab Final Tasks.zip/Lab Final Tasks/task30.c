#include <stdio.h>

int main() {
    int row, col;

    for (row = 1; row <= 7; row++) {
        for (col = 1; col <= 8; col++) {
            if (row <= 4) {
                if (col <= row || col >= 9 - row) {
                    printf("*");
                } else {
                    printf(" ");
                }
            } else {
                if (col <= 8 - row || col >= row + 1) {
                    printf("*");
                } else {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }
}