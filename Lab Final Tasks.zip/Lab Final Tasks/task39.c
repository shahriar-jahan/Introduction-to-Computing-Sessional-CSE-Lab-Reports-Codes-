#include <stdio.h>

int main() {
    int n1, n2, x, y, remainder, gcd, lcm;

    printf("Enter two integers: ");
    scanf("%d %d", &n1, &n2);

    x = n1;
    y = n2;

    while (y != 0) {
        remainder = x % y;
        x = y;
        y = remainder;
    }

    gcd = x;
    lcm = (n1 * n2) / gcd;

    printf("GCD = %d\n", gcd);
    printf("LCM = %d\n", lcm);
}