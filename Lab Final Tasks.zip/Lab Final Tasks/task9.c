//take a number and calculte sum 
/*Sample Input:
Enter an integer: 1234
Sample Output:
Sum=10
*/
#include<stdio.h>
int main()
{
int num,rem;
int sum=0;
printf("Enter an integer: ");
scanf("%d",&num);
if (num<0)
{
    num=-num;
}
while (num>0)
{
    rem=num%10;//get last digit
    sum=sum+rem;//add last digit to sum
    num=num/10;//remove last digit
}
printf("Sum=%d",sum);


}