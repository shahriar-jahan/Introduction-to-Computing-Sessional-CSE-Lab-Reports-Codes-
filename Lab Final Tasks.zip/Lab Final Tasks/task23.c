#include <stdio.h>

int main() {
    int row, col;

    for (row = 1; row <= 4; row++) {
        for (col = 1; col <= 7; col++) {
            
            if (col >= row && col <= 8 - row) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
}