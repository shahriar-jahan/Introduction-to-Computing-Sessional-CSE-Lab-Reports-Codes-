#include <stdio.h>

int main() {
    int row, col;

    for (row = 1; row <= 4; row++) {
        for (col = 1; col <= row; col++) {
            if ((row + col) % 2 == 0) {
                printf("1 ");
            } else {
                printf("0 ");
            }
        }
        printf("\n");
    }
}