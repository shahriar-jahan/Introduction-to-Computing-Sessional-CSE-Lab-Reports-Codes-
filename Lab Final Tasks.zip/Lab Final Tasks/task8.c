//Take an integer and count total digits
/*Sample Input:
Enter an integer: 45892
Sample Output:
Digits:5
*/
#include<stdio.h>
int main()
{
int num,count;
count=0;
printf("Enter an integer: ");
scanf("%d",&num);
if (num==0)
{
    count=1;
}
else{
    if (num<0)
    {
        num=-num;
    }
    while (num>0)
    {
        num=num/10;
        count++;
    }
    printf("Digits:%d\n",count);
}
}