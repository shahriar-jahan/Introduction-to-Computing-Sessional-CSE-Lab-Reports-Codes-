//Print Number from 10 to 1
/*Sample Output: 10 9 8 7 6 5 4 3 2 1*/
#include<stdio.h>
int main()
{
    int i;
    for ( i = 10; i>=1; i--)
    {
      printf("%d ",i);
    }
    
}