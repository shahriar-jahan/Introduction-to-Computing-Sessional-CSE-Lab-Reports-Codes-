#include <stdio.h>

int main() {
    int row, col;

    for (row = 1; row <= 5; row++) {
        for (col = 1; col <= 9; col++) {
            // Star paths: Left slope, Right slope, or Bottom base row
            if (col == 5 - (row - 1) || col == 5 + (row - 1) || row == 5) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
}