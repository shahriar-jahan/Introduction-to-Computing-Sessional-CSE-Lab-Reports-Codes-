#include <stdio.h>

int main() {
    int rows = 5, val = 1;
    for (int row = 0; row < rows; row++) {
        for (int space = 1; space <= rows - row; space++) {
            printf(" ");
        }
        for (int col = 0; col <= row; col++) {
            if (col == 0 || row == 0) {
                val = 1;
            } else {
                val = val * (row - col + 1) / col;
            }
            printf("%d ", val);
        }
        printf("\n");
    }
}