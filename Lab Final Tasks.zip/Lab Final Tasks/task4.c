//Display all odd number between 1 and 50
/*Sample Output:
1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49
*/
#include<stdio.h>
int main()
{
    int i;
    for ( i = 1; i <=50; i+=2)
    {
        printf("%d ",i);
    }
    
}