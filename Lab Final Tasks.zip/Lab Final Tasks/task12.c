//Menu Driven Calculator
/*Sample input and Output:
Enter Your Choice(1-5):2
Enter 1st & 2nd number: 6 2
Result= 4.00
Calculator Menu:
1.Addition
2.Subtraction
3.Multiplication
4.Division
5.Exit
Enter Your Choice(1-5):5
Enter 1st & 2nd number: 2 5
Exit*/
#include<stdio.h>
int main()
{
    int choice;
    double num1,num2;
    do
    {
        printf("Calculator Menu:\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Exit\n");
        printf("Enter Your Choice(1-5):");
        scanf("%d",&choice);
        printf("Enter 1st & 2nd number: ");
        scanf("%lf %lf",&num1,&num2);

    
    switch(choice)
    {
    case 1:
        printf("Result= %.2lf\n",num1+num2);
        break;
    case 2:
        printf("Result= %.2lf\n",num1-num2);
        break;
    case 3:
        printf("Result= %.2lf\n",num1*num2);
        break;
    case 4:
        printf("Result= %.2lf\n",num1/num2);
        break;
    case 5:
        printf("Exit\n");
        break;
    default:
        printf("Invalid!\n");
        break;
    }
    }
    while (choice!=5);
    
}