#include <stdio.h>

int main() {
    for (int i = 1; i <= 127; i++) {
        printf("ASCII value of %d = %c\n", i, i);
    }
}