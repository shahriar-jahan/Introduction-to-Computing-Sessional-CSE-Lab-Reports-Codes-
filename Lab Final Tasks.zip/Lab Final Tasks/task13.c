//Password Taking and correction
/*Sample Input and Output:
Enter 4 Digit Pass: 2345
Incorrect password!Please Try Again!
Enter 4 Digit Pass: 1234
Access Granted!*/
#include<stdio.h>
int main()
{
     int password;
    const int correct_pass=1234;
    do
    {
        printf("Enter 4 Digit Pass: ");
        scanf("%d",&password);
        if (password!=correct_pass)
        {
            printf("Incorrect password!Please Try Again!");
        }
        
    } while (password!=correct_pass);
    printf("Access Granted!");
    
    
}