//Fibonacci Series

#include<stdio.h>
int main()
{
    int n;
    int i=1,t1=0,t2=1;
    int nextTerm;
    printf("N= ");
    scanf("%d",&n);
    printf("Fibonacci Series:\n");
    for (i = 1; i<=n; i++)
    {
        printf("%d ",t1);
        nextTerm=t1+t2;
        t1=t2;
        t2=nextTerm;
    }
    
}