#include <stdio.h>

int main() {
    int n, originalNum, remainder, result = 0;

    printf("Enter a three-digit integer: ");
    scanf("%d", &n);

    originalNum = n;

    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += remainder * remainder * remainder;
        originalNum /= 10;
    }

    if (result == n) {
        printf("Armstrong number\n");
    } else {
        printf("Not an Armstrong number\n");
    }
}