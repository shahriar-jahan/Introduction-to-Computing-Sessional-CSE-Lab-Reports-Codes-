//display number from 1 to 20
/*Sample Output: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20*/
#include<stdio.h>
int main()
{
    int i=1;
    do
    {
        printf("%d ",i);
        i++;
    } while (i<=20);
    
}