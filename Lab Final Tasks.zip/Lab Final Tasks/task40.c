#include <stdio.h>

int main() {
    int n, originalNum, remainder, sum = 0;

    printf("Enter an integer: ");
    scanf("%d", &n);

    originalNum = n;

    while (n > 0) {
        remainder = n % 10;

        long long fact = 1;
        for (int i = 1; i <= remainder; i++) {
            fact *= i;
        }

        sum += fact;
        n /= 10;
    }

    if (sum == originalNum) {
        printf("Strong number\n");
    } else {
        printf("Not a Strong number\n");
    }
}