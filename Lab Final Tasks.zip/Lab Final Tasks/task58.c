#include <stdio.h>

int main() {
    int n;
    double sum = 0.0;
    printf("Enter N: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        sum += 1.0 / i;
    }
    printf("Sum of harmonic series = %.6f\n", sum);
    return 0;
}