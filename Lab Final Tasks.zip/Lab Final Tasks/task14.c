//Guessing Correct Number
/*Sample Input and Output:
Enter number: 4
Wrong Guess!
Enter number: 7
Right Guess!
*/
#include<stdio.h>
int main()
{
    int num;
    const int coreect_num=7;
    do
    {
       printf("Enter number: ");
       scanf("%d",&num);
       if (num!=coreect_num)
       {
        printf("Wrong Guess!\n");
       }
       
        
    } while (num!=coreect_num);
    printf("Right Guess!\n");
    
}